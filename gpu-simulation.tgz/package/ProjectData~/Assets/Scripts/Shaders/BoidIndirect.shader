Shader "Custom/BoidIndirect"
{
    Properties
    {
        _Color ("Color", Color) = (1, 1, 1, 1)
    }

    SubShader
    {
        Tags
        {
            "RenderType" = "Opaque"
            "RenderPipeline" = "UniversalPipeline"
            "Queue" = "Geometry"
        }

        Pass
        {
            Name "Forward"
            Cull Off

            HLSLPROGRAM

            #pragma vertex vert
            #pragma fragment frag

            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            #include "structs.compute"

            StructuredBuffer<Entity> entities;

            CBUFFER_START(UnityPerMaterial)
                float4 _Color;
            CBUFFER_END

            struct Attributes
            {
                float3 positionOS : POSITION;
                float3 normalOS : NORMAL;
                uint instanceID : SV_InstanceID;
            };

            struct Varyings
            {
                float4 positionCS : SV_POSITION;
                uint instanceID : TEXCOORD0;
            };

            Varyings vert(Attributes input)
            {
                Entity entity = entities[input.instanceID];

                float3 position = input.positionOS;

                float2 direction = normalize(entity.velocity);

                float2 rotatedPosition;
                rotatedPosition.x = position.x * direction.x - position.y * direction.y;
                rotatedPosition.y = position.x * direction.y + position.y * direction.x;

                position.xy = rotatedPosition;
                position.xy += entity.position;

                Varyings output;
                output.positionCS = TransformObjectToHClip(position);
                output.instanceID = input.instanceID;

                return output;
            }

            half4 frag(Varyings input) : SV_Target
            {
                float2 velocity = entities[input.instanceID].velocity;

                return float4(abs(velocity.x), abs(velocity.y), 0.0, 1.0);
            }

            ENDHLSL
        }
    }
}