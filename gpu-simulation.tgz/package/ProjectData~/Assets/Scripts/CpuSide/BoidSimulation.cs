using UnityEngine;

public class BoidSimulation : GPUSimulation
{
    [SerializeField] private Material material;
    [SerializeField] private Mesh mesh;
    [SerializeField] private int entityCount = 100000;
    [SerializeField] private int mapWidth = 100;
    [SerializeField] private int mapHeight = 100;
    [SerializeField] private bool donutMap = true;
    [SerializeField] private float perceptionRadius;
    [SerializeField] private float separationRadius;
    [SerializeField] private float separationStrength;
    [SerializeField] private float alignmentStrength;
    [SerializeField] private float cohesionStrength;
    [SerializeField] private float speed;

    private SimulationBuffer<Entity> entities;
    private ComputeBuffer argsBuffer;

    protected override void CreateBuffers()
    {
        entities = NewBuffer<Entity>(
            "entities",
            entityCount,
            "Update"
        );
        Entity[] data = new Entity[entityCount];

        for (int i = 0; i < entityCount; i++)
        {
            data[i] = new Entity
            {
                position = new Vector2(
                    Random.Range(0f, mapWidth),
                    Random.Range(0f, mapHeight)
                ),
                velocity = new Vector2(2, 2)// Random.insideUnitCircle.normalized * speed
            };
        }

        entities.Buffer.SetData(data);
    }

    private void Start()
    {
        if (mesh == null)
        {
            mesh = new Mesh();

            mesh.vertices = new Vector3[]
           {
            new Vector3(0.5f, 0.0f, 0.0f),
            new Vector3(-0.5f, 0.25f, 0.0f),
            new Vector3(-0.5f, -0.25f, 0.0f)
           };

            mesh.triangles = new int[]
            {
             0, 1, 2
            };

            mesh.RecalculateNormals();

        }
        uint[] args =
{
            mesh.GetIndexCount(0),
            (uint)entities.Count,
            mesh.GetIndexStart(0),
            mesh.GetBaseVertex(0),
            0
            };

        argsBuffer = new ComputeBuffer(1, args.Length * sizeof(uint), ComputeBufferType.IndirectArguments);
        argsBuffer.SetData(args);
    }

    private void Update()
    {
        simulationShader.SetBool("donutMap", donutMap);
        simulationShader.SetInt("width", mapWidth);
        simulationShader.SetInt("height", mapHeight);
        simulationShader.SetFloat("perceptionRadius", perceptionRadius);
        simulationShader.SetFloat("separationRadius", separationRadius);
        simulationShader.SetFloat("separationStrength", separationStrength);
        simulationShader.SetFloat("alignmentStrength", alignmentStrength);
        simulationShader.SetFloat("cohesionStrength", cohesionStrength);
        simulationShader.SetFloat("deltaTime", Time.deltaTime);
        simulationShader.SetFloat("speed", speed);
        Dispatch("Update", entities);
        Render();
    }

    private void Render()
    {
        material.SetBuffer("entities", entities.Buffer);

        Graphics.DrawMeshInstancedIndirect(
            mesh,
            0,
            material,
            new Bounds(Vector3.zero, Vector3.one * 10000f),
            argsBuffer
        );
    }

    private void OnDestroy()
    {
        argsBuffer?.Release();
    }
}

public struct Entity
{
    public Vector2 position;
    public Vector2 velocity;
}