using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;

public abstract class GPUSimulation : MonoBehaviour
{
    [SerializeField] protected ComputeShader simulationShader;

    private readonly Dictionary<string, int> kernelIDs = new();
    private readonly List<SimulationBuffer> buffers = new();

    protected virtual void Awake()
    {
        if (simulationShader == null)
        {
            Debug.LogError($"[{GetType().Name}] No ComputeShader assigned.");
            return;
        }

        CreateBuffers();
        CreateKernelCache();
        AssignBuffers();
    }

    protected abstract void CreateBuffers();

    private readonly HashSet<string> kernelNames = new();

    private void RegisterKernel(string kernel)
    {
        if (string.IsNullOrWhiteSpace(kernel))
        {
            return;
        }

        kernelNames.Add(kernel);
    }

    private void CreateKernelCache()
    {
        kernelIDs.Clear();

        foreach (string kernel in kernelNames)
        {
            int kernelID = simulationShader.FindKernel(kernel);
            kernelIDs[kernel] = kernelID;
        }
    }

    protected SimulationBuffer<T> NewBuffer<T>(
      string bufferName,
      int count,
      params string[] kernels) where T : struct
    {
        foreach (string kernel in kernels)
        {
            RegisterKernel(kernel);
        }

        int stride = Marshal.SizeOf<T>();

        SimulationBuffer<T> buffer = new(
            simulationShader,
            bufferName,
            count,
            stride,
            kernels,
            kernelIDs
        );

        buffers.Add(buffer);

        return buffer;
    }

    protected SimulationBuffer NewRawBuffer(
        string bufferName,
        int stride,
        int count,
        params string[] kernels)
    {
        if (stride <= 0)
        {
            throw new ArgumentOutOfRangeException(
                nameof(stride),
                "Buffer stride must be greater than zero."
            );
        }

        if (count <= 0)
        {
            throw new ArgumentOutOfRangeException(
                nameof(count),
                "Buffer count must be greater than zero."
            );
        }

        SimulationBuffer buffer = new(
            simulationShader,
            bufferName,
            count,
            stride,
            kernels,
            kernelIDs
        );

        buffers.Add(buffer);

        return buffer;
    }

    private void AssignBuffers()
    {
        foreach (SimulationBuffer buffer in buffers)
        {
            buffer.AssignToKernels();
        }
    }

    protected void Dispatch<T>(string kernel, SimulationBuffer<T> buffer)
        where T : struct
    {
        Dispatch(kernel, buffer.Count);
    }

    protected void Dispatch(string kernel, SimulationBuffer buffer)
    {
        Dispatch(kernel, buffer.Count);
    }

    protected void Dispatch(string kernel, int elementCount)
    {
        if (!kernelIDs.TryGetValue(kernel, out int kernelID))
        {
            Debug.LogError(
                $"[{GetType().Name}] Kernel '{kernel}' does not exist."
            );

            return;
        }

        simulationShader.GetKernelThreadGroupSizes(
            kernelID,
            out uint threadGroupSizeX,
            out uint threadGroupSizeY,
            out uint threadGroupSizeZ
        );

        int groupsX = Mathf.CeilToInt(
            elementCount / (float)threadGroupSizeX
        );

        simulationShader.Dispatch(
            kernelID,
            groupsX,
            1,
            1
        );
    }

    protected void Dispatch(
        string kernel,
        int elementsX,
        int elementsY)
    {
        if (!kernelIDs.TryGetValue(kernel, out int kernelID))
        {
            Debug.LogError(
                $"[{GetType().Name}] Kernel '{kernel}' does not exist."
            );

            return;
        }

        simulationShader.GetKernelThreadGroupSizes(
            kernelID,
            out uint threadGroupSizeX,
            out uint threadGroupSizeY,
            out uint threadGroupSizeZ
        );

        int groupsX = Mathf.CeilToInt(
            elementsX / (float)threadGroupSizeX
        );

        int groupsY = Mathf.CeilToInt(
            elementsY / (float)threadGroupSizeY
        );

        simulationShader.Dispatch(
            kernelID,
            groupsX,
            groupsY,
            1
        );
    }

    protected void Dispatch(
        string kernel,
        int elementsX,
        int elementsY,
        int elementsZ)
    {
        if (!kernelIDs.TryGetValue(kernel, out int kernelID))
        {
            Debug.LogError(
                $"[{GetType().Name}] Kernel '{kernel}' does not exist."
            );

            return;
        }

        simulationShader.GetKernelThreadGroupSizes(
            kernelID,
            out uint threadGroupSizeX,
            out uint threadGroupSizeY,
            out uint threadGroupSizeZ
        );

        int groupsX = Mathf.CeilToInt(
            elementsX / (float)threadGroupSizeX
        );

        int groupsY = Mathf.CeilToInt(
            elementsY / (float)threadGroupSizeY
        );

        int groupsZ = Mathf.CeilToInt(
            elementsZ / (float)threadGroupSizeZ
        );

        simulationShader.Dispatch(
            kernelID,
            groupsX,
            groupsY,
            groupsZ
        );
    }

    protected int GetKernelID(string kernel)
    {
        if (!kernelIDs.TryGetValue(kernel, out int kernelID))
        {
            Debug.LogError(
                $"[{GetType().Name}] Kernel '{kernel}' does not exist."
            );

            return -1;
        }

        return kernelID;
    }

    protected virtual void OnDestroy()
    {
        foreach (SimulationBuffer buffer in buffers)
        {
            buffer.Release();
        }

        buffers.Clear();
    }
}