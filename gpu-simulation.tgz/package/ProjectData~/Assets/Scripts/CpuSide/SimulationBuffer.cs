using System;
using System.Collections.Generic;
using UnityEngine;

public class SimulationBuffer
{
    protected readonly ComputeShader shader;
    protected readonly string bufferName;
    protected readonly int count;
    protected readonly int stride;
    protected readonly string[] kernels;
    protected readonly Dictionary<string, int> kernelIDs;

    protected ComputeBuffer buffer;

    public ComputeBuffer Buffer => buffer;
    public int Count => count;
    public int Stride => stride;
    public string Name => bufferName;

    public SimulationBuffer(
        ComputeShader shader,
        string bufferName,
        int count,
        int stride,
        string[] kernels,
        Dictionary<string, int> kernelIDs)
    {
        this.shader = shader;
        this.bufferName = bufferName;
        this.count = count;
        this.stride = stride;
        this.kernels = kernels;
        this.kernelIDs = kernelIDs;

        CreateBuffer();
    }

    private void CreateBuffer()
    {
        buffer = new ComputeBuffer(
            count,
            stride,
            ComputeBufferType.Structured
        );
    }

    public void AssignToKernels()
    {
        foreach (string kernel in kernels)
        {
            if (!kernelIDs.TryGetValue(kernel, out int kernelID))
            {
                Debug.LogError(
                    $"Kernel '{kernel}' does not exist while assigning " +
                    $"buffer '{bufferName}'."
                );

                continue;
            }

            shader.SetBuffer(
                kernelID,
                bufferName,
                buffer
            );
        }
    }

    public virtual void Release()
    {
        if (buffer == null)
        {
            return;
        }

        buffer.Release();
        buffer = null;
    }
}
public class SimulationBuffer<T> : SimulationBuffer where T : struct
{
    public SimulationBuffer(
        ComputeShader shader,
        string bufferName,
        int count,
        int stride,
        string[] kernels,
        Dictionary<string, int> kernelIDs)
        : base(
            shader,
            bufferName,
            count,
            stride,
            kernels,
            kernelIDs)
    {
    }

    public void SetData(T[] data)
    {
        if (data == null)
        {
            throw new ArgumentNullException(nameof(data));
        }

        if (data.Length > count)
        {
            throw new ArgumentException(
                $"Buffer '{bufferName}' has a capacity of {count}, " +
                $"but {data.Length} elements were provided."
            );
        }

        buffer.SetData(data);
    }

    public void SetData(
        T[] data,
        int managedBufferStartIndex,
        int computeBufferStartIndex,
        int count)
    {
        buffer.SetData(
            data,
            managedBufferStartIndex,
            computeBufferStartIndex,
            count
        );
    }

    public void GetData(T[] data)
    {
        buffer.GetData(data);
    }

    public void GetData(
        T[] data,
        int managedBufferStartIndex,
        int computeBufferStartIndex,
        int count)
    {
        buffer.GetData(
            data,
            managedBufferStartIndex,
            computeBufferStartIndex,
            count
        );
    }
}