using Unity.VisualScripting;
using UnityEngine;

public class FPSCounter : MonoBehaviour
{
    [SerializeField] private float updateInterval;
    private float accumulatedTime;
    [SerializeField] private int fps;
    private int interalFps; 

    // Update is called once per frame
    void Update()
    {
        interalFps = (int)(1f / Time.unscaledDeltaTime); // Calculate FPS based on unscaled delta time
        accumulatedTime += Time.deltaTime;
        if(accumulatedTime >= updateInterval)
        {
            fps = interalFps;
            accumulatedTime = 0f;
        }
    }
}
